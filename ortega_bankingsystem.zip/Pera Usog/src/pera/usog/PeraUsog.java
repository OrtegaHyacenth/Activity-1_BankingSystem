/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pera.usog;


import java.util.Scanner;

/**
 *
 * @author home
 */
public class PeraUsog {

    /**
     * @param args the command line arguments
     */

     
    public static void main(String[] args) {
       Scanner scanner =new Scanner(System.in);
       int bal = 0;
        int choice;

       
       do{
        System.out.println("-----MENU-----"); 
        System.out.println(" [1] DEPOSIT:");      
        System.out.println(" [2] WITHDRAW:");              
        System.out.println(" [3] CHECK BALANCE");
        System.out.println(" [4] EXIT");      
        choice = scanner.nextInt();
       
        switch (choice){
            
            case 1:
                System.out.println(" Enter your amount to deposit:");
               int deposit = scanner.nextInt();
                 bal = deposit;
                System.out.println("You deposited:$" + deposit);
                System.out.println("Your total deposit is:$" + bal);
                              
                System.out.println("Would you like to make another transaction?"
                        + " \n Press [y], if YES \n Press [n], if NO");
                String AnotherDeposit = scanner.next();
                break;
            case 2:
                        boolean validWithdrawal = false;
                    while (!validWithdrawal) {
                        System.out.print("Enter the withdrawal amount: $");
                       double withdrawalAmount = scanner.nextDouble();

                        if (bal != 0) {
                            System.out.println("You withdrawn:$" +withdrawalAmount  );
                        } else {
                            System.out.println("Invalid withdrawal amount or insufficient funds. Try again.");
                        }
                     System.out.println("Would you like to make another transaction?"
                        + " \n Press 1, if YES \n Press 2, if NO");
                 String AnotherWithdrawal = scanner.next();
                break;    
               }
               
            case 3:
            System.out.println("Your current balance is:$" + bal);
                System.out.println("Would you like to make another transaction?"
                        + " \n Press 1, if YES \n Press 2, if NO");
                String CurrentBal = scanner.next();
                break;
        }
    }while (choice!=4);
       
}
        
    
}